package com.nihar.practice;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class TestRandomString {
	
	public static String randomAlphaNumeric(int count) {
		String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
		int character = (int)(Math.random()*ALPHA_NUMERIC_STRING.length());
		builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		builder.append(getRandomString());
		return builder.toString();
	}
	
	public  static Long  generateRandomNumber(){
		Long x= (long) 9999 ;
		Long y=(long) 999999;
		Random r = new Random();
		long randomLong = x+((long)(r.nextDouble()*(y-x)));
		return randomLong;

	}
	
	
	public static String getRandomString(){
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = new Date();
		String randomString= dateFormat.format(date) + ""+generateRandomNumber();
		return randomString;
	}
	
	public static void main(String args[]){
		System.out.println(randomAlphaNumeric(30));
		System.out.println(getRandomString());
	}

}
