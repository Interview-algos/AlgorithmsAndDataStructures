package com.nihar.practice;

public class TestJavaArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = {1,3,5,7,9,11};
		for (int i:arr){
			System.out.println(i);
		}
		
	}

}
