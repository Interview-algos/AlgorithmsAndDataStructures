package com.nihar.practice;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.google.common.collect.ImmutableMap;
import com.nihar.datamodel.Season;

public class TestListInitialization {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map<String, String> test = ImmutableMap.<String, String>builder()
			    .put("k1", "v1")
			    .put("k2", "v2")
			    .build();
		
		List<String> al = new ArrayList<String>(Arrays.asList("", ""));
		//al.add("pqr");

		System.out.println("==============");
		Iterator<String> itr=al.iterator();//getting Iterator from arraylist to traverse elements  
		  while(itr.hasNext()){  
		   System.out.println(itr.next());  
		  }  
		  System.out.println("==============");
		  
		  Date d1 = new Date(999113923);
		  System.out.println(d1.toString());
		  
		  SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		  //System.out.println(sdf.format(new GregorianCalendar(2011, Calendar.JULY, 3).getTime()));
		  //System.out.println(new GregorianCalendar(2011, Calendar.JULY, 3).getTime().toString());
		  
		  System.out.println(new Date(1990, 11, 21).toString());
		  
		  
		  //Convert ArrayList value to comma separated string
		  List<String> ids = new ArrayList<String>(Arrays.asList("xyz", "abc"));
		  
		  String csv = String.join(",", ids);
		  
		  System.out.println(csv);
		  
		  List<Season> ids1 = new ArrayList<Season>(Arrays.asList(Season.FALL, Season.SPRING));
		  
		  StringBuffer metadataStr = new StringBuffer();
			int size = ids1.size();
			for (int i=0; i< size;i++){
				if(!(i == (size-1))){
					metadataStr.append(ids1.get(i).toString() + ",");
				}else{
					metadataStr.append(ids1.get(i).toString());
				}
					
			}
			
			System.out.println(metadataStr.toString());
			
			System.out.println("alkka;lkasd" + new Boolean(null));
	}

}
