package com.nihar.practice;

import com.nihar.datamodel.Season;

public class EnumExample {
	
public static void printEnum(Season s){
		
		System.out.println(s);
		
	}
	public static void main(String[] args) {  
		//Season s=Season.WINTER;  
		//System.out.println(s);  
		
		printEnum(Season.SPRING);
	}	

}
