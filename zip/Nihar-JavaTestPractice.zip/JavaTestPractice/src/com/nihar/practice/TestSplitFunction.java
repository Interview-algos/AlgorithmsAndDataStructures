package com.nihar.practice;

import java.io.CharArrayWriter;
import java.io.FileWriter;
import java.io.IOException;

public class TestSplitFunction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String test = "Hi I am Nihar";
		String abc[] = test.split("\\s");
		for (String a:abc){
			System.out.println(a);
		}
		
		Runtime r=Runtime.getRuntime();  
		  System.out.println("Total Memory: "+r.totalMemory());  
		  System.out.println("Free Memory: "+r.freeMemory());  
		    
		  for(int i=0;i<10000;i++){  
		   new TestSplitFunction();  
		  }  
		  System.out.println("After creating 10000 instance, Free Memory: "+r.freeMemory());  
		  System.gc();  
		  System.out.println("After gc(), Free Memory: "+r.freeMemory());  
		  
		  try{
		  CharArrayWriter out=new CharArrayWriter();  
		  out.write("My name is Nihar");  
		  
		  FileWriter f1=new FileWriter("a.txt");  
		  FileWriter f2=new FileWriter("b.txt");  
		  FileWriter f3=new FileWriter("c.txt");  
		  FileWriter f4=new FileWriter("d.txt");  
		  
		  
		  out.writeTo(f1);  
		  out.writeTo(f2);  
		  out.writeTo(f3);  
		  out.writeTo(f4);  
		  
		  
		  f1.close();  
		  f2.close();  
		  f3.close();  
		  f4.close();  
		  }catch(IOException e){}

	}

}
