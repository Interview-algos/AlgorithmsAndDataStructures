package com.nihar.datamodel;

public enum Season { 
	
	WINTER, 
	SPRING, 
	SUMMER, FALL 
} 