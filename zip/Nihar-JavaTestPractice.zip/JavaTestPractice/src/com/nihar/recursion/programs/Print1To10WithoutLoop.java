package com.nihar.recursion.programs;

public class Print1To10WithoutLoop {

	public static void recursivePrint(int n){
		
		if (n<=10){
			System.out.println(n);
			recursivePrint(n+1);
		}
	}
	public static void main(String[] args) {
		recursivePrint(1);

	}

}
