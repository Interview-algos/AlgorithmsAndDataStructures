package com.nihar.important.program;

public class CountStringLengthWithoutLengthFunction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "LalKSlskSsSlsl";
		int count = 0;
		
		for (char c:str.toCharArray()){
			count++;
		}
		
		System.out.println(count);

	}

}
